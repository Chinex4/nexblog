import React from 'react';

const Show = ({ blog }) => {
    return (
        <Authenticated
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Blog {blog.id}</h2>}
        >
            <div className='py-12 max-w-7xl mx-auto sm:px-6 lg:px-8'>
                <h1>{blog.title}</h1>
                <p>{blog.body}</p>
                <p>By {blog.user.name}</p>
                <small>Created at {blog.user.created_at}</small>
            </div>
        </Authenticated>
    );
};

export default Show;
