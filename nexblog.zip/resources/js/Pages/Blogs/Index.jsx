import React from 'react'
import { Link } from '@inertiajs/react'
import Authenticated from '@/Layouts/AuthenticatedLayout'
const Index = ({ blogs, auth }) => {
    return (
        <Authenticated
            user={auth.user}
            header={<h2 className="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">Blogs</h2>}
        >
            <div className='py-12 max-w-7xl mx-auto sm:px-6 lg:px-8'>

                <Link className='border rounded-md px-4 py-2 text-white hover:text-gray-800 hover:bg-white transition-all duration-300' href="/blogs/create">Create New Blog</Link>

                {blogs ? (
                    <ul className='mt-10 text-white grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5'>
                        {blogs.map(blog => (
                            <li className='border px-6 py-8 rounded-lg' key={blog.id}>
                                <p>
                                    {blog.title}
                                </p>
                                <p>
                                    <span>
                                        By {blog.user.name}
                                    </span> 
                                </p>
                                <Link className='inline-block rounded-lg mt-8 bg-blue-500 px-4 py-2' href={`/blogs/${blog.id}`}>
                                    View Blog
                                </Link>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No Blogs to Show.</p>
                )}

            </div>
        </Authenticated>
    )
}

export default Index
